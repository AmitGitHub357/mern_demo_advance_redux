import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, Navigate } from "react-router-dom";
const View = () => {
  const [filterStatus, setFilterStatus] = useState("All");
  const [listFilter, setListFilter] = useState([]);
  const [list, setList] = useState([]);
  const setData = (e, data) => {
    localStorage.setItem("id", data);
  };

  const filterList = async (e) => {
    e.preventDefault();
    setFilterStatus(e.target.value);
    const res = await axios.get(
      `http://localhost:5000/api/project/filterList?projectStatus=${filterStatus}`
    );
    await setListFilter(res.data);

    console.log(listFilter);
    if (filterStatus !== "All") {
      setList(listFilter);
    }
    console.log(list);
  };

  const fetchData = () => {
    axios.get("http://localhost:5000/api/project/").then((resp) => {
      setList(resp.data);
    });
  };

  useEffect(() => {
    fetchData();
    // filterList(e)
  }, []);

  const deleteHandler = (e, id) => {
    axios
      .delete(`http://localhost:5000/api/project/${id}`)
      .then((res) => {
        alert("Record Deleted" + res.status);
        const newList = list.filter((item) => {
          return item._id !== id;
        });
        // console.log(list);
        setList(newList);
      })
      .catch((err) => {
        console.log(err.message);
      });
  };

  return (
    <>
      <div className="container mt-3">
        <h2>Projects</h2>
        <p>Filter</p>
        <div className="col-md-2">
          <select
            className="form-control text-center"
            onChange={(e) => filterList(e)}
          >
            <option value="All">All</option>
            <option value="Completed">Completed</option>
            <option value="Ongoing">Ongoing</option>
            <option value="Upcoming">Upcoming</option>
          </select>
        </div>
        <table className="table table-striped">
          <thead>
            <tr>
              <th>Name</th>
              <th>Images</th>
              <th>Description</th>
              <th>Status</th>
              <th colSpan={2} className="text-center">
                action
              </th>
            </tr>
          </thead>
          <tbody>
            {typeof list.ProjectList !== "undefined" ? (
              list.ProjectList.map((item) => {
                return (
                  <tr key={item.id}>
                    <td>{item.name}</td>
                    <td>
                      <img src={item.images} />
                    </td>
                    <td>{item.description}</td>
                    <td>{item.projectStatus}</td>
                    <td>
                      <button
                        className="btn text-danger bg-white"
                        onClick={(e) => deleteHandler(e, item._id)}
                      >
                        Delete
                      </button>
                    </td>
                    <td>
                      <Link to="/edit">
                        <button
                          className="btn bg-secondary text-white"
                          onClick={(e) => setData(e, item._id)}
                        >
                          Update
                        </button>
                      </Link>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td>loading</td>{" "}
              </tr>
            )}
          </tbody>
        </table>
        <div>
          <Link to="/">
            <button className="btn btn-dark">Add Project</button>
          </Link>
          <Link to="/projectView">
            <button className="">Project View</button>
          </Link>
        </div>
      </div>
    </>
  );
};

export default View;
