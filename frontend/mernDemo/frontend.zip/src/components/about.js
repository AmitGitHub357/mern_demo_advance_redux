import React from "react"
  const About = () => {
    return ( <div className="container mt-5">
    {/* <!-- <div id="header"></div> --> */}
    <div className="row justify-content-center">
      <div className="col-md-6">
        <h1 className="text-center">About Us</h1>
        <p className= "mt-4 text-secondary">
          Metromindz Software PVT. LTD. Sahakar Nagar Benglore Aenean
          vulputate eleifend tellus. Aenean leo ligula, porttitor eu,
          consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in.
        </p>
        <p className="mt-4  text-secondary" >
          Metromindz Software PVT. LTD. Sahakar Nagar Benglore Aenean
          vulputate eleifend tellus. Aenean leo ligula, porttitor eu,
          consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in.<a href="#" className="text-secondary">more</a>
        </p>
        <p className="mt-4  text-secondary" >
          Metromindz Software PVT. LTD. Sahakar Nagar Benglore Aenean
          vulputate eleifend tellus. Aenean leo ligula, porttitor eu,
          consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in.<a href="#" className="text-secondary">more</a>
        </p>
      </div>
      <div className="col-md-6 mt-5">
        <img
          src="https://www.acv.app/static/media/RemoteTeamAnimate.9bc87be4.svg"
        />
      </div>
    </div>
   
  </div>)

  }

  export default About